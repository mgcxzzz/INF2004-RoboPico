# RoboPico RTOS v0.4.3

Flash the UF2 through BOOTSEL. Start Demo Console v0.2.15 from this bundle.
On macOS, run `python3 tools/dashboard/run_dashboard.py` in the extracted folder.
Confirm v0.4.3 in the firmware badge.

At Baseline 45, repeat the left-turn approach to the second obstacle.
A clean stopped batch with one echo down to 260 mm can proceed when the
other two are in 270–330 mm, all three agree within 15 mm, and tape
and turn clearance checks pass. The dashboard records
“accepted with range warning” in the event timeline when this happens.

Check for the width probe, bypass, and line rejoin. If it still holds,
press Stop and download the run ZIP before Reset.
