/**
 * @file buddy_hooks.c
 * @brief Buddy hooks.
 * @details Public feature contract. Requests cross coordinator ownership
 * checks; callers observe completion/status separately and must respect task
 * context.
 * @see docs/architecture.md and this feature's README for the full logic.
 */
#include "include/interfaces/buddy_hooks.h"
/* Replace these no-ops with Buddy5's non-blocking ultrasonic/state machine,
 * or supply strong definitions in another source added to CMake. */
__attribute__((weak)) void buddy_extension_init (void)
{
}
__attribute__((weak)) void buddy_extension_poll (uint64_t now_us)
{
    (void)now_us;
}

/* End of file. */
