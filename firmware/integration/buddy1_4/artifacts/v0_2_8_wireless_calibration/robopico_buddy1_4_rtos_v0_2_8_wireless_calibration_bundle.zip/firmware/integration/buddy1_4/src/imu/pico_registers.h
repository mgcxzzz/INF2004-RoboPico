/**
 * @file pico_registers.h
 * @brief Pico registers.
 * @details Sensor processing owns calibration/terrain state; RTOS readers use
 * copies. Height acceptance and motor assistance are separate from end-run
 * safety.
 * @see docs/architecture.md and this feature's README for the full logic.
 */
/* Buddy4-on-v2.3: the only definitions the validated RTOS driver
 * (drv_lsm303.c) took from micro T-Kernel / sys_hal, re-expressed for the
 * Pico SDK build. Values are the RP2040 register addresses and bits from
 * include/sys/sysdepend/cpu/rp2040/sysdef.h and tk/.../syslib.h of the RTOS
 * tree (identical to the SDK address map). No behaviour of its own. */
#ifndef V23B4_RP2040_SHIM_H
#define V23B4_RP2040_SHIM_H
#include <stdbool.h>
#include <stdint.h>
#include <stddef.h>
#ifdef APP_RTOS_IMU
extern uint64_t
board_time_us (void); /* Verified migration TIMER; no SDK runtime. */
#else
#include "hardware/timer.h" /* time_us_32() */
#endif

static inline void out_w (uint32_t first, uint32_t value)
{
    *(volatile uint32_t *)(uintptr_t)first = value;
}
static inline uint32_t in_w (uint32_t first)
{
    return *(volatile uint32_t *)(uintptr_t)first;
}
static inline void clr_w (uint32_t first, uint32_t value)
{
    *(volatile uint32_t *)(uintptr_t)(first + 0x3000U) = value;
}
static inline void set_w (uint32_t first, uint32_t value)
{
    *(volatile uint32_t *)(uintptr_t)(first + 0x2000U) = value;
}
static inline uint32_t sys_time_us (void)
{
#ifdef APP_RTOS_IMU
    return (uint32_t)board_time_us();
#else
    return time_us_32();
#endif
}

#define V23B4_RESETS_BASE (0x4000C000U)
#define V23B4_IO_BANK0_BASE (0x40014000U)
#define V23B4_PADS_BANK0_BASE (0x4001C000U)
#define RESETS_RESET (V23B4_RESETS_BASE + 0x0U)
#define RESETS_RESET_DONE (V23B4_RESETS_BASE + 0x8U)
#define RESETS_RESET_I2C1 (0x00000010U)
#define GPIO_CTRL(n) (V23B4_IO_BANK0_BASE + 0x04U + ((n) * 8U))
#define GPIO_CTRL_FUNCSEL_I2C (3U)
#define GPIO(n) (V23B4_PADS_BANK0_BASE + 0x4U + ((n) * 4U))
#define GPIO_IE (1U << 6)
#define GPIO_DRIVE_4MA (1U << 4)
#define GPIO_PUE (1U << 3)
#define GPIO_SHEMITT (1U << 1)
#endif

/* End of file. */
