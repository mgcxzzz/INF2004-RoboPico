/**
 * @file bringup_policy.h
 * @brief Bringup policy.
 * @details Core1 owns normal motor commits. Safety paths may only remove
 * output; command/status access uses the existing kernel locks and copied
 * records.
 * @see docs/architecture.md and this feature's README for the full logic.
 */
#ifndef RTOS_BRINGUP_POLICY_H
#define RTOS_BRINGUP_POLICY_H

#include <stdbool.h>
#include <stdint.h>

enum
{
    BR_CONTROL_US = 10000U,
    BR_LATE_US = 50000U,
    BR_PULSE_US = 3000000U,
    BR_REST_US = 1000000U,
    BR_STALL_US = 750000U,
    BR_SPEED_MM_S = 45,
    BR_CLOCK_WINDOW_US = 1000000U,
    BR_CLOCK_GOOD_WINDOWS = 3
};
enum
{
    BR_ACTIVE = 1U,
    BR_ESTOP = 2U,
    BR_CLOCK_OK = 4U,
    BR_READY = 8U,
    BR_STALL = 16U,
    BR_LATE = 32U,
    BR_ENCODER = 64U,
    BR_IMU = 128U,
    BR_OBSTACLE_HOLD = 256U, /* Buddy5 is stopped and waits for Stop. */
    BR_LATCHED = BR_ESTOP | BR_STALL | BR_LATE | BR_ENCODER | BR_IMU
};
enum
{
    BR_REASON_BOOT,
    BR_REASON_DONE,
    BR_REASON_SERIAL,
    BR_REASON_GP20,
    BR_REASON_GP21,
    BR_REASON_USB,
    BR_REASON_CLOCK,
    BR_REASON_LATE,
    BR_REASON_STALL,
    BR_REASON_ENCODER,
    BR_REASON_API,
    BR_REASON_ADC,
    BR_REASON_NETWORK,
    BR_REASON_IMU_LIFT = 13U,
    BR_REASON_IMU_OVERTURN = 14U,
    BR_REASON_IMU_UNAVAILABLE = 15U
};

enum
{
    BR_GAP_NONE,
    BR_GAP_REVALIDATE,
    BR_GAP_STOP
};

static inline unsigned br_control_gap_action (uint16_t flags,
                                              uint32_t elapsed_us)
{
    if (elapsed_us < BR_LATE_US)
    {
        return BR_GAP_NONE;
    }
    return (flags & BR_ACTIVE) != 0U ? BR_GAP_STOP : BR_GAP_REVALIDATE;
}

static inline bool br_clock_elapsed_ok (uint32_t timer_us, uint32_t kernel_ms)
{
    if ((kernel_ms < 900U) || (kernel_ms > 1200U))
    {
        return false;
    }
    uint32_t expected = kernel_ms * 1000U;
    uint32_t error =
        timer_us > expected ? timer_us - expected : expected - timer_us;
    return error <= 5000U + expected / 100U;
}

/* Production release uses the existing fresh MQTT/network supervisor. The
 * migration bench profiles retain terminal-DTR supervision. */
static inline bool br_usb_supervised (unsigned usb)
{
#ifdef APP_RTOS_RELEASE
    (void)usb;
    return true;
#else
    return 3U == usb;
#endif
}

static inline bool br_can_start (uint16_t flags, uint32_t now, uint32_t stopped,
                                 unsigned usb, bool buttons_released)
{
    return ((((flags & (BR_READY | BR_CLOCK_OK | BR_ACTIVE | BR_LATCHED)) ==
              (BR_READY | BR_CLOCK_OK)) &&
             (now - stopped >= BR_REST_US)) &&
            (br_usb_supervised(usb))) &&
           buttons_released;
}

/* The release IMU guard is a copied cross-core observation. Keep it separate
 * from BR_LATCHED so a stale/unready sensor can inhibit motion without
 * manufacturing a sticky lifted/overturned latch. */
static inline bool br_safety_allows_motion (uint16_t flags, bool imu_blocked)
{
    return 0U == (flags & BR_LATCHED) && (!imu_blocked);
}

static inline bool br_can_clear_latch (uint16_t flags, bool buttons_released,
                                       bool imu_reset_allowed)
{
    return 0U == (flags & BR_ACTIVE) && ((flags & BR_CLOCK_OK) != 0U) &&
           buttons_released && imu_reset_allowed;
}

static inline bool br_command_fresh (uint32_t now, uint32_t received)
{
    return now - received <= 500000U;
}

static inline bool br_command_after_stop (uint32_t now, uint32_t received,
                                          uint32_t stopped, bool stop_seen)
{
    return (br_command_fresh(now, received)) &&
           (((!stop_seen) || (now - stopped > 500000U)) ||
            ((int32_t)(received - stopped) > 0));
}

static inline bool br_outputs_allowed (uint16_t flags, bool irq_latched,
                                       unsigned usb, bool buttons_released)
{
    return ((((flags & (BR_ACTIVE | BR_CLOCK_OK | BR_LATCHED)) ==
              (BR_ACTIVE | BR_CLOCK_OK)) &&
             (!irq_latched)) &&
            (br_usb_supervised(usb))) &&
           buttons_released;
}

#endif

/* End of file. */
