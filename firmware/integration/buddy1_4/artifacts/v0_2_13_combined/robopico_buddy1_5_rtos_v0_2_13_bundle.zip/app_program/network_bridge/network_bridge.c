/**
 * @file network_bridge.c
 * @brief Network bridge.
 * @details Application tasks exchange copied, bounded command and telemetry
 * records. The kernel Wi-Fi service owns the transport; reconnect never
 * restarts motion.
 * @see docs/architecture.md and this feature's README for the full logic.
 */
#include "../rtos_bringup/bringup.h"
#include "network_bridge.h"
#include "network_policy.h"
#include "connected_policy.h"
#if defined(APP_RTOS_RELEASE) && defined(APP_RTOS_IMU)
#include "../imu_navigation/imu_service.h"
#endif
#ifdef APP_RTOS_LINE
#include "../line_navigation/line_service.h"
#endif
#include "src/network/wifi_protocol.h"
#include "src/network/wifi_packets.h"
#include <string.h>

enum
{
    TX_CAPACITY = 1024,
    ACK_CAPACITY = 256,
    RX_CAPACITY = 256
};
static ID g_tx_queue;
static ID g_ack;
static ID g_rx_queue;
static ID g_heartbeat_queue;
static uint32_t g_barrier;
static uint32_t g_urgent;
static uint8_t g_accepted;
static uint8_t g_rejected;
static uint8_t g_last_command;
static uint8_t g_last_result;
static volatile uint32_t g_app_last_ms;
uint32_t rn_app_last_ms (void)
{
    return __atomic_load_n(&g_app_last_ms, __ATOMIC_ACQUIRE);
}
static T_SPLOCK g_lock;
static volatile uint32_t g_ready;
static rn_status_t g_network_status;
static uint32_t g_published;
static uint32_t g_received;
static uint32_t g_tx_dropped;
static uint32_t g_rx_dropped;
/* Source9 motion and11 navigation describe the present, not queued history.
 * Other telemetry (including mapping replies), ACKs and heartbeat retain
 * their own MBFs. Every slot is copied under the short bridge lock. */
typedef struct
{
    uint32_t ms;
    uint8_t data[RN_PACKET_MAX];
    uint8_t len : 7;
    uint8_t ready : 1;
} latest_telemetry_t;
static latest_telemetry_t g_latest[2];
static unsigned g_next_latest;
static uint32_t g_tx_coalesced;
static uint32_t g_mapping_snapshot;
static uint8_t g_source_sequence[16];
#ifdef APP_RTOS_IMU
static struct
{
    uint32_t samples;
    uint32_t radio_us;
    uint32_t timers_us;
    uint32_t mqtt_us;
    uint32_t max_radio_us;
    uint32_t max_timers_us;
    uint32_t max_mqtt_us;
    uint32_t max_total_us;
} g_service_timing;
#endif

static UINT enter (void)
{
    UINT key;
    (void)ISpinLock(&g_lock, &key);
    return key;
}
static void leave (UINT key)
{
    (void)ISpinUnlock(&g_lock, key);
}
#ifdef APP_RTOS_IMU
void rn_service_sample (uint32_t radio_us, uint32_t timers_us, uint32_t mqtt_us)
{
    UINT key = enter();
    ++g_service_timing.samples;
    g_service_timing.radio_us = radio_us;
    g_service_timing.timers_us = timers_us;
    g_service_timing.mqtt_us = mqtt_us;
    if (radio_us > g_service_timing.max_radio_us)
    {
        g_service_timing.max_radio_us = radio_us;
    }
    if (timers_us > g_service_timing.max_timers_us)
    {
        g_service_timing.max_timers_us = timers_us;
    }
    if (mqtt_us > g_service_timing.max_mqtt_us)
    {
        g_service_timing.max_mqtt_us = mqtt_us;
    }
    uint32_t total = radio_us + timers_us + mqtt_us;
    if (total > g_service_timing.max_total_us)
    {
        g_service_timing.max_total_us = total;
    }
    leave(key);
}
#endif
uint32_t rn_mapping_snapshot (void)
{
    UINT key = enter();
    uint32_t value = g_mapping_snapshot;
    leave(key);
    return value;
}
uint8_t rn_next_sequence (unsigned source)
{
#ifdef APP_RTOS_BUDDY5
    /* The single MQTT consumer numbers source 15 in queue order. */
    if (15U == source)
    {
        return 0U;
    }
#endif
    if (source >= 16)
    {
        return 0;
    }
    UINT key = enter();
    uint8_t value = g_source_sequence[source]++;
    leave(key);
    return value;
}
static void count_drop (bool receive)
{
    UINT key = enter();
    uint32_t * p_value = receive ? &g_rx_dropped : &g_tx_dropped;
    if (*p_value != UINT32_MAX)
    {
        ++*p_value;
    }
    leave(key);
}
static ID buffer (unsigned capacity, unsigned maximum)
{
    T_CMBF definition = {0};
    definition.mbfatr = TA_TFIFO;
    definition.bufsz = capacity;
    definition.maxmsz = maximum;
    return tk_cre_mbf(&definition);
}
int32_t rn_init (void)
{
    if ((g_tx_queue = buffer(TX_CAPACITY, 70)) < E_OK)
    {
        return g_tx_queue;
    }
    if ((g_ack = buffer(ACK_CAPACITY, 70)) < E_OK)
    {
        return g_ack;
    }
    if ((g_heartbeat_queue = buffer(128, 70)) < E_OK)
    {
        return g_heartbeat_queue;
    }
#if defined(APP_RTOS_LINE)
    int32_t drive = rn_drive_init();
    if (drive < E_OK)
    {
        return drive;
    }
#endif
    if ((g_rx_queue = buffer(RX_CAPACITY, RN_RX_BYTES)) < E_OK)
    {
        return g_rx_queue;
    }
    __atomic_store_n(&g_ready, 1U, __ATOMIC_RELEASE);
    return E_OK;
}
bool rn_ready (void)
{
    return __atomic_load_n(&g_ready, __ATOMIC_ACQUIRE) != 0;
}
static void put32 (uint8_t * p_data, uint32_t value)
{
    for (unsigned index = 0; index < 4; ++index)
    {
        p_data[index] = (uint8_t)(value >> (index * 8));
    }
}
static uint32_t get32 (const uint8_t * p_data)
{
    return (uint32_t)p_data[0] | ((uint32_t)p_data[1] << 8) |
           ((uint32_t)p_data[2] << 16) | ((uint32_t)p_data[3] << 24);
}
bool rn_tx_push (uint8_t topic, const uint8_t * p_data_value, uint8_t len,
                 uint32_t now)
{
    if (((!rn_ready()) || (!p_data_value)) || 0 == len ||
        (len > RN_PACKET_MAX) || (topic > RN_HB))
    {
        return false;
    }
    if (RN_TLM == topic && (9 == (p_data_value[0] >> 4) ||
                            (11 == (p_data_value[0] >> 4) && (len >= 8) &&
                             WPK_EVENT_STATUS == p_data_value[7])))
    {
        unsigned index = 9 == (p_data_value[0] >> 4) ? 0 : 1;
        UINT key = enter();
        if ((g_latest[index].ready) && (g_tx_coalesced != UINT32_MAX))
        {
            ++g_tx_coalesced;
        }
        memcpy(g_latest[index].data, p_data_value, len);
        g_latest[index].len = len;
        g_latest[index].ms = now;
        g_latest[index].ready = true;
        leave(key);
        return true;
    }
    uint8_t message[70];
    put32(message, now);
    message[4] = topic;
    message[5] = len;
    memcpy(message + 6, p_data_value, len);
    if (tk_snd_mbf(RN_ACK == topic  ? g_ack
                   : RN_HB == topic ? g_heartbeat_queue
                                    : g_tx_queue,
                   message, len + 6, TMO_POL) == E_OK)
    {
        return true;
    }
    count_drop(false);
    return false;
}
#ifdef APP_RTOS_BUDDY5
/* Free bytes in the bounded telemetry queue (non-blocking reference). Lets
 * the Buddy5 record stream back off so it never crowds out Buddy1-4 frames. */
uint32_t rn_tx_free (void)
{
    T_RMBF queue;
    if ((g_tx_queue < E_OK) || (E_OK != tk_ref_mbf(g_tx_queue, &queue)))
    {
        return 0U;
    }
    return queue.frbufsz < 0 ? 0U : (uint32_t)queue.frbufsz;
}
#endif
bool rn_tx_take (uint8_t * p_topic_value, uint8_t data[RN_PACKET_MAX],
                 uint8_t * p_len_value, uint32_t now)
{
    return rn_tx_take_budget(p_topic_value, data, p_len_value, now, true);
}
bool rn_tx_take_budget (uint8_t * p_topic_value, uint8_t data[RN_PACKET_MAX],
                        uint8_t * p_len_value, uint32_t now, bool telemetry)
{
    if (!rn_ready())
    {
        return false;
    }
    /* Bound stale-message cleanup too: never block the kernel Wi-Fi service. */
    for (unsigned count_value = 0; count_value < 4; ++count_value)
    {
        uint8_t message[70];
        INT count = tk_rcv_mbf(g_ack, message, TMO_POL);
        if (count < 0)
        {
            count = tk_rcv_mbf(g_heartbeat_queue, message, TMO_POL);
        }
        if ((count < 0) && telemetry)
        {
            count = tk_rcv_mbf(g_tx_queue, message, TMO_POL);
        }
        if (count < 0)
        {
            break;
        }
#ifdef APP_RTOS_BUDDY5
        /* Several tasks enqueue source 15 independently. Number admitted
         * frames in dequeue order, including frames that expired in the
         * queue. A retry cannot publish an older sequence after a newer one. */
        if ((count >= 9) && (RN_TLM == message[4]) && (0xf2U == message[6]))
        {
            message[8] = g_source_sequence[15]++;
        }
#endif
        if ((((count < 7) || (message[5] > RN_PACKET_MAX)) ||
             (count != message[5] + 6)) ||
            now - get32(message) > (RN_TLM == message[4] ? 250U : 2000U))
        {
            count_drop(false);
            if (3 == count_value)
            {
                return false; /* Bound cleanup without bypassing remaining ACKs.
                               */
            }
            continue;
        }
        *p_topic_value = message[4];
        *p_len_value = message[5];
        memcpy(data, message + 6, *p_len_value);
        return true;
    }
    if (telemetry)
    {
        for (unsigned count_value_value = 0; count_value_value < 2;
             ++count_value_value)
        {
            UINT key = enter();
            unsigned index = g_next_latest;
            g_next_latest ^= 1;
            latest_telemetry_t * p_slot = &g_latest[index];
            bool valid = (p_slot->ready) && (now - p_slot->ms <= 250U);
            bool stale = (p_slot->ready) && (!valid);
            if (valid)
            {
                *p_topic_value = RN_TLM;
                *p_len_value = p_slot->len;
                memcpy(data, p_slot->data, *p_len_value);
            }
            p_slot->ready = false;
            leave(key);
            if (stale)
            {
                count_drop(false);
            }
            if (valid)
            {
                return true;
            }
        }
    }
    return false;
}
bool rn_rx_push (const uint8_t * p_data_value, uint8_t copied,
                 uint32_t original, uint32_t now)
{
    if (((!rn_ready()) || (!p_data_value)) || (copied > RN_RX_MAX))
    {
        return false;
    }
    uint8_t message[RN_RX_BYTES] = {0};
    wifi_command_t command;
    bool valid = (original == copied) &&
                 WP_ACK_ACCEPTED == wp_parse(p_data_value, original, &command);
    UINT stamp_key = enter();
    if (valid && (WP_CMD_STOP == command.code || WP_CMD_ESTOP == command.code ||
                  WP_CMD_PAUSE == command.code))
    {
        ++g_barrier;
        g_urgent |= WP_CMD_ESTOP == command.code  ? RN_URGENT_ESTOP
                    : WP_CMD_STOP == command.code ? RN_URGENT_STOP
                                                  : RN_URGENT_PAUSE;
    }
    put32(message + 13, g_barrier);
    put32(message + 17, g_network_status.connects);
    put32(message + 21, (uint32_t)board_time_us());
    leave(stamp_key);
    put32(message, now);
    message[4] =
        (original <= RN_RX_MAX) && (original == copied) ? (uint8_t)original : 9;
    memcpy(message + 5, p_data_value, copied);
    if (E_OK == tk_snd_mbf(g_rx_queue, message, sizeof(message), TMO_POL))
    {
        UINT key = enter();
        if (g_received != UINT32_MAX)
        {
            ++g_received;
        }
        leave(key);
        return true;
    }
    count_drop(true);
    return false;
}
void rn_command_result (uint8_t code, uint8_t result)
{
    UINT key = enter();
    if (WP_ACK_ACCEPTED == result)
    {
        if (g_accepted != 255)
        {
            ++g_accepted;
        }
    }
    else if (g_rejected != 255)
    {
        ++g_rejected;
    }
    g_last_command = code;
    g_last_result = result;
    leave(key);
}
uint32_t rn_barrier (void)
{
    UINT key = enter();
    uint32_t value = g_barrier;
    leave(key);
    return value;
}
unsigned rn_take_urgent (void)
{
    UINT key = enter();
    unsigned value = g_urgent & (RN_URGENT_STOP | RN_URGENT_ESTOP);
    g_urgent &= ~(RN_URGENT_STOP | RN_URGENT_ESTOP);
    leave(key);
    return value;
}
bool rn_take_pause (void)
{
    UINT key = enter();
    bool value = (g_urgent & RN_URGENT_PAUSE) != 0;
    g_urgent &= ~RN_URGENT_PAUSE;
    leave(key);
    return value;
}
void rn_status_update (const rn_status_t * p_value)
{
    if (!rn_ready())
    {
        return;
    }
    UINT key = enter();
    g_network_status = *p_value;
    leave(key);
}
rn_status_t rn_status (void)
{
    UINT key = enter();
    rn_status_t result = g_network_status;
    result.published = g_published;
    result.received = g_received;
    result.tx_dropped = g_tx_dropped;
    result.rx_dropped = g_rx_dropped;
    result.tx_coalesced = g_tx_coalesced;
    leave(key);
    return result;
}
void rn_publish_result (bool ok_value_value)
{
    if (!ok_value_value)
    {
        count_drop(false);
        return;
    }
    UINT key = enter();
    if (g_published != UINT32_MAX)
    {
        ++g_published;
    }
    leave(key);
}
void rn_report (void)
{
    rn_status_t state = rn_status();
#ifdef APP_RTOS_LINE
    const char * p_mode = "USB_SUPERVISED";
#else
    const char * p_mode = "DISABLED";
#endif
    tm_printf((UB *)"NET motors=%s configured=%u connected=%u subscribed=%u "
                    "link=%d polls=%u last_ms=%u published=%u received=%u "
                    "tx_drop=%u rx_drop=%u mqtt_result=%d\n",
              p_mode, !!(state.flags & RN_CONFIGURED),
              !!(state.flags & RN_CONNECTED), !!(state.flags & RN_SUBSCRIBED),
              state.link, state.polls, state.last_poll_ms, state.published,
              state.received, state.tx_dropped, state.rx_dropped,
              state.mqtt_result);
    tm_printf((UB *)"NET_ADDRESS ip=%u.%u.%u.%u broker=%u.%u.%u.%u\n",
              state.ipv4 & 255U, (state.ipv4 >> 8) & 255U,
              (state.ipv4 >> 16) & 255U, state.ipv4 >> 24,
              state.broker_ipv4 & 255U, (state.broker_ipv4 >> 8) & 255U,
              (state.broker_ipv4 >> 16) & 255U, state.broker_ipv4 >> 24);
    tm_printf((UB *)"NET_TX coalesced=%u mem=%u errors=%u deferred=%u "
                    "result=%d free_req=%u ring_used=%u tcp_free=%u "
                    "nagle_off=%u admit_ms=%u complete_ms=%u\n",
              state.tx_coalesced, state.publish_mem, state.publish_error,
              state.telemetry_wait, state.publish_result, state.request_free,
              state.ring_used, state.tcp_free, state.nagle_off,
              state.last_admit_ms, state.last_complete_ms);
    tm_printf((UB *)"NET_MEMORY heap_used=%u heap_max=%u heap_capacity=%u "
                    "heap_errors=%u tcp_queue=%u tcp_retries=%u tcp_rto_ms=%u "
                    "oversize=0\n",
              state.heap_used, state.heap_max, state.heap_capacity,
              state.heap_errors, state.tcp_queue, state.tcp_retries,
              state.tcp_rto_ms);
#ifdef APP_RTOS_IMU
    UINT key = enter();
    uint32_t sample[] = {
        g_service_timing.samples,      g_service_timing.radio_us,
        g_service_timing.timers_us,    g_service_timing.mqtt_us,
        g_service_timing.max_radio_us, g_service_timing.max_timers_us,
        g_service_timing.max_mqtt_us,  g_service_timing.max_total_us};
    leave(key);
    tm_printf((UB *)"NET_SERVICE core=0 samples=%u radio_us=%u timers_us=%u "
                    "mqtt_us=%u max_radio_us=%u max_timers_us=%u "
                    "max_mqtt_us=%u max_total_us=%u\n",
              sample[0], sample[1], sample[2], sample[3], sample[4], sample[5],
              sample[6], sample[7]);
#endif
}
void rn_app_task (int32_t code, void * p_exinf_value)
{
    (void)code;
    (void)p_exinf_value;
    uint32_t last_hb = board_kernel_ms(), mapping = 0, previous_connects = 0;
    uint8_t sequence = 0, map_sequence = 0;
    for (;;)
    {
        uint32_t now = board_kernel_ms();
        __atomic_store_n(&g_app_last_ms, now, __ATOMIC_RELEASE);
        rn_status_t net = rn_status();
        bringup_status_t motion;
        bringup_get_status(&motion);
        uint8_t state =
            rn_drive_state(motion.flags, false, false, motion.reason);
#ifdef APP_RTOS_LINE
        state = rn_drive_state(motion.flags, rn_drive_paused(),
                               rtos_line_pending(), motion.reason);
        rn_drive_telemetry(now);
#endif
        bool force_hb = false;
        uint8_t message[RN_RX_BYTES];
        for (unsigned count = 0;
             (count < 4) &&
             RN_RX_BYTES == tk_rcv_mbf(g_rx_queue, message, TMO_POL);
             ++count)
        {
            wifi_command_t command;
#ifdef APP_RTOS_LINE
            uint8_t parsed = wp_parse(message + 5, message[4], &command);
            if (!parsed &&
                (WP_CMD_START == command.code || WP_CMD_PAUSE == command.code ||
                 WP_CMD_RESUME == command.code || WP_CMD_RESET == command.code
#ifdef APP_RTOS_RELEASE
                 || WP_CMD_GET_LOG == command.code ||
                 (WP_CMD_CONFIG == command.code &&
                  (WP_CONFIG_DRIVE_MODE_KEY == (command.arg & 0xffU) ||
                   WP_CONFIG_CALIBRATION_KEY == (command.arg & 0xffU)))
#endif
                     ))
            {
                if (rn_drive_enqueue(message))
                {
                    continue; /* ACK follows actual owner decision. */
                }
                uint8_t reply[4];
                wp_ack(&command, WP_ACK_BUSY, state, reply);
                rn_command_result(command.code, WP_ACK_BUSY);
                (void)rn_tx_push(RN_ACK, reply, sizeof(reply), now);
                continue;
            }
#endif
            rn_command_plan_t plan =
                rn_bench_command(message + 5, message[4], get32(message), now,
                                 &mapping, &command);
#ifdef APP_RTOS_LINE
            if ((!parsed) && WP_CMD_CONFIG == command.code &&
                1U == (command.arg >> 12) && (now - get32(message) <= 500U))
            {
                rn_drive_set_telemetry((command.arg & 4095U) != 0);
                plan.result = WP_ACK_ACCEPTED;
            }
#endif
            uint8_t result = plan.result;
            UINT map_key = enter();
            g_mapping_snapshot = mapping;
            leave(map_key);
            bool send_map = (plan.flags & RN_PLAN_MAP) != 0;
            force_hb |= (plan.flags & RN_PLAN_HEARTBEAT) != 0;
            if (plan.flags & RN_PLAN_STOP)
            {
                bringup_stop_from(BR_REASON_NETWORK,
                                  plan.flags & RN_PLAN_ESTOP ? BR_ESTOP : 0,
                                  MOTION_BUDDY1);
            }
            if (plan.flags & RN_PLAN_ESTOP)
            {
                state = 5;
            }
            rn_command_result(command.code, result);
            uint8_t packet[8];
            wp_ack(&command, result, state, packet);
            (void)rn_tx_push(RN_ACK, packet, WP_ACK_BYTES, now);
            if (send_map)
            {
                wp_map_frame(mapping, command.id, map_sequence++, packet);
                (void)rn_tx_push(RN_TLM, packet, WP_MAP_FRAME_BYTES, now);
            }
        }
        if (net.connects != previous_connects)
        {
            uint8_t map[WP_MAP_FRAME_BYTES];
            wp_map_frame(mapping, 0, map_sequence++, map);
            (void)rn_tx_push(RN_TLM, map, sizeof(map), now);
            previous_connects = net.connects;
            force_hb = true;
        }
#ifdef APP_RTOS_RELEASE
        static uint32_t release_last;
        if (now - release_last >= 1000U)
        {
            release_last = now;
            uint8_t mode_info[17];
            rtos_line_drive_mode_info(rn_next_sequence(15), now, mode_info);
            (void)rn_tx_push(RN_TLM, mode_info, sizeof(mode_info), now);
            uint8_t calibration[RL_CAL_FRAME_BYTES];
            rtos_line_cal_info(rn_next_sequence(15), calibration);
            (void)rn_tx_push(RN_TLM, calibration, sizeof(calibration), now);
            uint8_t info[16];
            rtos_line_release_info(rn_next_sequence(15), info);
            (void)rn_tx_push(RN_TLM, info, sizeof(info), now);
            /* Always retain fault visibility, including ordinary telemetry-off.
             * These APIs copy owner snapshots; no live decoder access here. */
            uint8_t encoder_fault[BR_ENCODER_FAULT_PACKET_BYTES];
            bringup_encoder_fault_packet(rn_next_sequence(15), encoder_fault);
            (void)rn_tx_push(RN_TLM, encoder_fault, sizeof(encoder_fault), now);
            uint8_t network_stop[RN_NETWORK_STOP_PACKET_BYTES];
            rn_network_stop_packet(rn_next_sequence(15), network_stop);
            (void)rn_tx_push(RN_TLM, network_stop, sizeof(network_stop), now);
            if (rn_drive_telemetry_enabled())
            {
                uint8_t attempt[30];
                rtos_line_barcode_attempt_info(rn_next_sequence(15), now,
                                               attempt);
                (void)rn_tx_push(RN_TLM, attempt, sizeof(attempt), now);
                uint8_t junction[20], drive[18];
                rtos_line_junction_info(rn_next_sequence(15), now, junction);
                (void)rn_tx_push(RN_TLM, junction, sizeof(junction), now);
                rtos_line_drive_info(rn_next_sequence(15), now, drive);
                (void)rn_tx_push(RN_TLM, drive, sizeof(drive), now);
            }
#ifdef APP_RTOS_IMU
            uint8_t lift_stop[30];
            uint16_t run = (uint16_t)info[13] | ((uint16_t)info[14] << 8);
            ri_safety_packet(rn_next_sequence(15), run, lift_stop);
            (void)rn_tx_push(RN_TLM, lift_stop, sizeof(lift_stop), now);
            uint8_t lift_peak[28];
            ri_safety_peak_packet(rn_next_sequence(15), lift_peak);
            (void)rn_tx_push(RN_TLM, lift_peak, sizeof(lift_peak), now);
            if (rn_drive_telemetry_enabled())
            {
                uint8_t diagnostics[63];
                ri_release_diagnostics(rn_next_sequence(15), now, diagnostics);
                (void)rn_tx_push(RN_TLM, diagnostics, sizeof(diagnostics), now);
            }
#endif
        }
#endif
        if (rn_heartbeat_due(now, &last_hb, force_hb))
        {
            /* A Stop/Reset may have executed in this pass. Advertise the
             * current supervisor state, not the snapshot before dispatch. */
            bringup_get_status(&motion);
            state = rn_drive_state(motion.flags, false, false, motion.reason);
#ifdef APP_RTOS_LINE
            state = rn_drive_state(motion.flags, rn_drive_paused(),
                                   rtos_line_pending(), motion.reason);
#endif
            UINT key = enter();
            wifi_heartbeat_t heartbeat = {
                .seq = sequence++,
                .net = net.flags & RN_SUBSCRIBED ? 2
                       : 3 == net.link           ? 1
                                                 : 0,
                .state = state,
                .last_cmd = g_last_command,
                .last_result = g_last_result,
                .uptime_s =
                    (uint16_t)(now / 1000U > 16383U ? 16383U : now / 1000U),
                .published =
                    net.published > 65535U ? 65535U : (uint16_t)net.published,
                .lost =
                    net.tx_dropped > 65535U ? 65535U : (uint16_t)net.tx_dropped,
                .accepted = g_accepted,
                .rejected = g_rejected,
                .connects = net.connects > 255U ? 255U : (uint8_t)net.connects};
            leave(key);
            T_RMBF queue;
            if (E_OK == tk_ref_mbf(g_tx_queue, &queue))
            {
                heartbeat.fill_pct = (uint8_t)((TX_CAPACITY - queue.frbufsz) *
                                               100U / TX_CAPACITY);
            }
            uint8_t packet[WPK_HEARTBEAT_BYTES];
            if (wpk_heartbeat(&heartbeat, packet))
            {
                (void)rn_tx_push(RN_HB, packet, sizeof(packet), now);
            }
        }
        (void)tk_dly_tsk(10);
    }
}

/* End of file. */
