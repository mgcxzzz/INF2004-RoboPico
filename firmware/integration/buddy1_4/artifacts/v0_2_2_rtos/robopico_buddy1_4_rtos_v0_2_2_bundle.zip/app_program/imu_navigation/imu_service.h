#ifndef RTOS_IMU_SERVICE_H
#define RTOS_IMU_SERVICE_H
#include "../rtos_bringup/bringup.h"
#include "imu_motion.h"
/* Short 50Hz acquisition work precedes background USB3/WiFi4 on core0.
 * Motor/navigation/safety priorities and sole output owner stay on core1. */
#define RI_TASK_PRIORITY 2
#define RI_TASK_PROCESSOR TP_PRC1
void ri_init(void);
void ri_task(INT code, void *exinf);
void ri_report(void);
#ifdef APP_RTOS_RELEASE
void ri_release_diagnostics(uint8_t seq, uint32_t now_ms, uint8_t out[63]);
#endif
void ri_reset_request(void);
void ri_observe(const MotionFeedback *f, const uint32_t invalid[2], uint32_t dt_us, bool running);
void ri_tilt_snapshot(b4v23_tilt_t *out);
#endif
