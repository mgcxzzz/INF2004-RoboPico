################################################################################
# micro T-Kernel 3.0 BSP  makefile
################################################################################

# app_program/*.c plus one level of subfolders (one per subsystem)
TEMP_SRCS = $(wildcard ../app_program/*.c) $(wildcard ../app_program/*/*.c)
ifeq ($(BUDDY3_ISOLATED),1)
# Uploaded S3 replaces the template consumer. Do not compile the old
# producer/consumer/monitor tasks or their obsolete interface declarations.
TEMP_SRCS = ../app_program/buddy3_isolated.c \
    ../app_program/subsystem3/subsystem3.c \
    ../app_program/subsystem3/drv_ir.c \
    ../app_program/subsystem3/barcode_decoder.c \
    ../app_program/subsystem3/s3_weak_hooks.c
# This source includes standard stddef.h before the kernel header. Use its
# existing size_t instead of asking syslib.h to typedef a second one.
mtkernel_3/app_program/subsystem3/subsystem3.o: CFLAGS += -DPROHIBIT_DEF_SIZE_T
endif
TEMP_OBJS = $(TEMP_SRCS:.c=.o)
TEMP_DEPS = $(TEMP_SRCS:.c=.d)

OBJS += $(subst ../, ./mtkernel_3/, $(TEMP_OBJS))
C_DEPS += $(subst ../, ./mtkernel_3/, $(TEMP_DEPS))

mtkernel_3/app_program/%.o: ../app_program/%.c
	@echo 'Building file: $<'
	@mkdir -p $(dir $@)
	$(GCC) $(CFLAGS) -D$(TARGET) $(INCPATH) -MF"$(@:%.o=%.d)" -MT"$(@)" -c -o "$@" "$<"
	@echo 'Finished building: $<'
	@echo ' '
