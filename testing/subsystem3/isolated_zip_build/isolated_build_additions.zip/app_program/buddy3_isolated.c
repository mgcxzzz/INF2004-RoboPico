/* Isolated build entry for the supplied Buddy 3 module.
 * No motion/navigation implementation or synthetic odometer is supplied.
 * The uploaded subsystem3/*.c/.h files are compiled unchanged.
 */
#include <tk/tkernel.h>
#include <tm/tmonitor.h>
#include <bsp/libbsp.h>
#include "subsystem3/subsystem3.h"
#include "subsystem3/drv_ir.h"

EXPORT INT usermain(void)
{
    UINT pin;
    for (pin=8; pin<=11; ++pin) {
        gpio_set_val(pin, 0);
        gpio_set_pin(pin, GPIO_MODE_OUT);
    }
    subsystem3_init();
    subsystem3_start();
    for (;;) {
        uint32_t ir = drv_ir_read();
        uint32_t speed = s3_get_speed_word();
        tm_printf((UB*)"S3 ISOLATED (no motor control): raw=%u,%u,%u black=%u,%u,%u speed_word=0x%08x diag=0x%08x\n",
            gpio_get_val(DRV_IR_PIN_LEFT), gpio_get_val(DRV_IR_PIN_RIGHT),
            gpio_get_val(DRV_IR_PIN_BARCODE), (ir>>0)&1U, (ir>>1)&1U,
            (ir>>2)&1U, speed, s3_get_diag_word());
        tk_dly_tsk(250);
    }
    return 0;
}
